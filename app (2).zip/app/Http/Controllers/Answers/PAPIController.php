<?php

namespace App\Http\Controllers\Answers;

use App\Http\Controllers\AnswerController;
use Illuminate\Http\Request;

class PAPIController extends AnswerController
{
    //
}
