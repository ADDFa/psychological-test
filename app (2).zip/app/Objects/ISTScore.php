<?php

namespace App\Objects;

use App\Models\Answers\An;
use App\Models\Answers\Fa;
use App\Models\Answers\Ge;
use App\Models\Answers\Me;
use App\Models\Answers\Ra;
use App\Models\Answers\Se;
use App\Models\Answers\Wa;
use App\Models\Answers\Wu;
use App\Models\Answers\Zr;
use App\Models\IQUser;
use App\Models\ISTClassification;
use App\Models\ISTScore as ModelsISTScore;
use App\Models\User;
use App\Models\UserTest;

class ISTScore
{
    private static array $result = [];
    private static int $userId;
    private static int $examId;

    public static function classification($userId, $examId)
    {
        self::$result["iq"] = IQUser::with("norma")->where("user_id", $userId)->first();
        self::$result["classification"] = ISTClassification::where("user_id", $userId)->first();
        self::$userId = $userId;
        self::$examId = $examId;
        return new static();
    }

    public function scores()
    {
        self::$result["scores"] = ModelsISTScore::where("user_id", self::$userId)->get();
        return $this;
    }

    public function answers()
    {
        self::$result["answers"] = [
            "se"    => Se::with("question")->get(),
            "an"    => An::with("question")->get(),
            "fa"    => Fa::with("question")->get(),
            "ge"    => Ge::with("question")->get(),
            "me"    => Me::with("question")->get(),
            "ra"    => Ra::with("question")->get(),
            "wa"    => Wa::with("question")->get(),
            "wu"    => Wu::with("question")->get(),
            "zr"    => Zr::with("question")->get(),
        ];
        return $this;
    }

    public function user()
    {
        self::$result["user"] = User::find(self::$userId);
        return $this;
    }

    public function userTest()
    {
        self::$result["user_test"] = UserTest::where("user_id", self::$userId)->where("exam_id", self::$examId)->first();
        return $this;
    }

    public function result()
    {
        return self::$result;
    }
}
